import click
import json
import os
from pathlib import Path
from habit_tracker import Habit, User          
        

def login():
    """
    Log's the user in by assigning an existing user or creating a new user
    """
    saved_users = restore()
    click.echo("\n")
    click.echo("Hello user!\nExisting Users:\n")
    for user in saved_users:
        click.echo(user.get_name())
    name = click.prompt("\nWhat is your name?", type=str)
    for user in saved_users:
        if user.get_name() == name:
            click.echo("\nYou've successfully logged in.")
            navigation(user)
    if click.confirm(f'\nThe user {name} does not exist.\nDo you want to create a new user with this name?'):
        age = click.prompt("\nHow old are you?", type=int)
        click.echo("\nYou've successfully created a new user.\n\n\n")
        user = User(name, age)
        save(user)
        navigation(user)
    else:
        return login()


def navigation(user):
    """
    Show's available command's to navigate through the programm
    
    Parameters
    ----------
    user : User
        A user object
    """
    commands = [
        "manage",
        "analyse",
        "user info",
        "logout",
        "exit"
    ]
    click.echo("\nCommands:")
    for command in commands:
        click.echo("\t" + command)
    user.refresh_habits()
    match click.prompt("", type=click.Choice(commands), show_choices=False):
        case "manage":
            manage(user)
        case "analyse":
            analyse(user)
        case "user info":
            user_info(user)
        case "logout":
            save(user)
            login()
        case "exit":
            exit()
            
    
def manage(user):
    """
    Show's available command's to manage the habits of the user
    
    Parameters
    ----------
    user : User
        A user object
    """
    commands = [
        "create habit",
        "change periodicity",
        "delete habit",
        "complete habit",
        "back"
    ]
    click.echo("\nCommands:")
    for command in commands:
        click.echo("\t" + command)
    user.refresh_habits()
    match click.prompt("",type=click.Choice(commands), show_choices=False):
        case "create habit":
            return create_habit(user)
        case "change periodicity":
            return change_periodicity(user)
        case "delete habit":
            return delete_habit(user)
        case "complete habit":
            return complete_habit(user)
        case "back":
            return navigation(user)
    
def save(user):
    """
    Saves a user object to a file
    
    Parameters
    ----------
    user : User
        A user object
    """
    try:
        current_directory = Path(__file__)
        program_folder = str(current_directory.parent)
        save_path = program_folder + "\\Users\\"
        os.makedirs(save_path + user.get_name())
        
    except FileExistsError:
        pass
    
    json_dictionary = user.__dict__
    json_string = json.dumps(json_dictionary, default=lambda o: '<not serializable>')
    json_dictionary = json.loads(json_string)
    del json_dictionary["habits"]
    json_string = json.dumps(json_dictionary)
    with open(program_folder + "\\Users\\" + user.get_name() + ".txt", 'w') as f:
        f.write(json_string)
    if user.get_all_habits():
        for habit in user.get_all_habits():
            json_dictionary = habit.__dict__
            json_str = json.dumps(json_dictionary)
            with open(program_folder + "\\Users\\" + user.get_name() + "\\" + habit.get_task() + ".txt", 'w') as f:
                f.write(json_str)
        
def restore():
    """
    Restore's user objects from json files located in the project folder "\\Users\\
    """
    project_path = os.path.split(__file__)[0]
    if not os.path.exists(project_path + "\\Users\\"):
        return []
    restored_users = []
    user_path = project_path + "\\Users\\"
    for element in os.listdir(user_path):
        if os.path.isfile(os.path.join(user_path, element)):
            json_string = open(user_path + element, "r").read()
            user = User.load_user_from_json(json_string)
            username = os.path.splitext(os.path.join(user_path, element))[0]
            username = username.split("\\")
            username = username[-1]
            for element in os.listdir(os.path.join(user_path, username)):
                json_string = open(os.path.join(user_path, username, element), "r").read()
                habit = Habit.load_habit_from_json(json_string)
                user.recreate_habit(habit)
            restored_users.append(user)
    return restored_users

def create_habit(user):
    """
    Takes user input to create a new habit for the user logged in
    
    Parameters
    ----------
    user : User
        A user object
    """
    task = click.prompt("\nWhats the name of the new habit?", type=str)
    if task.lower() in user.get_all_tasks():
        click.echo("\nHabit already exists")
        manage(user)
    else:
        if task.lower() == "back":
            manage(user)
    periodicity = click.prompt("Whats the periodicity?", type=click.Choice(["daily", "weekly", "back"]))
    if periodicity.lower() == "back":
            manage(user)
    if click.confirm(f"Confirm:\n" + task + "\n" + periodicity+ "\n"):
        user.add_habit(task, periodicity)
        click.echo("\n---------------------------------------------\nSuccessfully created new habit\n---------------------------------------------")
        
        save(user)
        
    return manage(user)

def change_periodicity(user):
    """
    Takes user input to change the periodicity of a specific habit object
    
    Parameters
    ----------
    user : User
        A user object
    """
    click.echo("\nYour habit's...\n")
    if not user.get_all_habits():
        click.echo("\nYou have no habits saved yet")
        return manage(user)
    for habit in user.get_all_habits():
        click.echo(habit.get_task() + " : " + str(habit.get_periodicity()))
    click.echo("\nback")
    options = user.get_all_tasks()
    options.append("back")
    task = click.prompt("\nWhats the name of the habit you want to change?", type=click.Choice(options), show_choices=False)
    if task == "back":
        return manage(user)
    habit = user.get_habit(task)
    habit.change_periodicity()
    click.echo("\n---------------------------------------------\nSuccessfully changed periodicity to " + str(habit.get_periodicity()) + "\n---------------------------------------------")
    save(user)
    return manage(user)

def delete_habit(user):
    """
    Takes user input to delete a specific habit of the user
    
    Parameters
    ----------
    user : User
        A user object
    """
    click.echo("\nYour habit's...")
    for habit in user.get_all_habits():
        click.echo(habit.get_task())
    options = user.get_all_tasks()
    options.append("back")
    task = click.prompt("\nWhats the name of the habit you want to delete?", type=click.Choice(options), show_choices=False)
    if task.lower() == "back":
            manage(user)
    
    if click.confirm(f"Confirm deleting:\n" + task + "\n"):
        user.remove_habit(task)
        click.echo("\n---------------------------------------------\nSuccessfully removed the habit: " + task + "\n---------------------------------------------")
    save(user)
    return manage(user)

def complete_habit(user): 
    """
    Takes user input to complete a specific habit of the user
    
    Parameters
    ----------
    user : User
        A user object
    """   
    click.echo("\nYour habit's...")
    for habit in user.get_all_habits():
        click.echo(habit.get_task())
        options = user.get_all_tasks()
        options.append("back")
    task = click.prompt("\nWhats the name of the habit you want to complete?", type=click.Choice(options), show_choices=False)
    if task.lower() == "back":
            manage(user)
    if user.get_habit(task) in user.get_all_habits():
        if click.confirm(f'\nComplete the task'):
            user.set_complete(task)
            click.echo("\n---------------------------------------------\nSuccessfully completed the habit :" + task + "\n---------------------------------------------")
            save(user)
        return manage(user)
    click.echo("\nHabitname " + task + " does not exist")
    return complete_habit(user)
    
    
def analyse(user):
    """
    Show's available command's to analyse the habits of the user
    
    Parameters
    ----------
    user : User
        A user object
    """
    commands = [
        "completed",
        "incompleted",
        "most struggle",
        "current streaks",
        "longest streaks",
        "daily habits",
        "weekly habits",
        "all habits",
        "back"
        ]
    click.echo("\nCommands:")
    for command in commands:
        click.echo("\t" + command)
    user.refresh_habits()
    match click.prompt("",type=click.Choice(commands), show_choices=False):
        case "completed":
            completed(user)
        case "incompleted":
            incompleted(user)
        case "most struggle":
            most_struggle(user)
        case "current streaks":
            current_streaks(user)
        case "longest streaks":
            longest_streaks(user)
        case "daily habits":
            daily_habits(user)
        case "weekly habits":
            weekly_habits(user)
        case "all habits":
            all_habits(user)
        case "back":
            navigation(user)

def completed(user):
    """
    Show's all completed habits
    
    Parameters
    ----------
    user : User
        A user object
    """
    click.echo("\nYour completed habit's...\n")
    for completed in user.get_completed()[0]:
        click.echo(completed[0] + " : " + completed[1])
    return analyse(user)
    

def incompleted(user):
    """
    Show's all incompleted habits
    
    Parameters
    ----------
    user : User
        A user object
    """
    click.echo("\nYour incompleted habit's...\n")
    for incompleted in user.get_completed()[1]:
        click.echo(incompleted[0] + " : " + incompleted[1])
    return analyse(user)   

def most_struggle(user):
    """
    Show's the habits the user struggled the most in the last specified days or weeks
    """
    days = click.prompt("\nDays to look past", type=int)
    weeks = click.prompt("\nWeeks to look past", type=int)
    click.echo("\nYour most daily struggle habit's are...[task, number of incompletion\n")
    for habit in user.daily_struggle(days):
        click.echo(habit)
    
        
    click.echo("\nYour most weekly struggle habit's are...\n")
    for habit in user.weekly_struggle(weeks):
        click.echo(habit)
    return analyse(user)
    
def current_streaks(user):
    streaks = user.get_current_streaks()
    for element in streaks:
        click.echo(element[0] + ": " +str(element[1]))
    return analyse(user)
    
def longest_streaks(user):
    streaks = user.get_longest_streaks()
    for element in streaks:
        click.echo(element[0] + ": " + str(element[1]))
    return analyse(user)
        
def daily_habits(user):
    click.echo("\nYour daily habit's are...\n")
    for habit in user.get_daily_habits():
        click.echo(habit)
    return analyse(user)
        
def weekly_habits(user):
    click.echo("\nYour weekly habit's are...\n")
    for habit in user.get_weekly_habits():
        click.echo(habit)
    return analyse(user)
        
def all_habits(user):
    click.echo("\nYour habit's are...\n")
    for habit in user.get_all_tasks():
        click.echo(habit)
    return analyse(user)

def user_info(user):
    click.echo("\nUsername: " + user.get_name())
    click.echo("Age: " + str(user.get_age()))
    click.echo("Creation: " + user.get_creation() + "\n")
    return navigation(user)
    
    
    
    
def main():
    login()
    
    
if __name__ == "__main__":
    main()