from habit_tracker import Habit, User
import json
from datetime import datetime, timedelta


def test_load_habit_from_json():
    
    json_string = json.dumps({"_task_specification": "test",
                "_periodicity": "daily",
                "_date_of_creation": "01-01-1900",
                "_streak": 0,
                "_completed": True,
                "_history": [],
                "_streak_history": [],
                "_completion_history": [["01-01-1900", "12-00-00"]]
                })
    
    habit = Habit.load_habit_from_json(json_string)
    new_json_string = json.dumps(habit.__dict__)
    assert json_string == new_json_string
    
def test_refresh_broken():
    habit = Habit(task_specification="test", 
                periodicity="daily",
                date_of_creation = (datetime.now() - timedelta(days=2)).strftime('%d-%m-%y'),
                streak=3,
                completed=True,
                history=[0],
                streak_history=[0],
                completion_history=[[
                    (datetime.now().date() - timedelta(days=2)).strftime('%d-%m-%y'),
                    (datetime.now() - timedelta(days=2)).strftime('%H-%M-%S')
                    ]]
                )
    
    habit.refresh()
    completed = habit.get_completed()
    completion_history = habit.get_history()
    streak = habit.get_streak()
    assert completed == False
    assert completion_history[-1] == 0
    assert streak==0
    
def test_refresh_streak():
    habit = Habit(task_specification="test", 
                periodicity="daily",
                date_of_creation = datetime.now().strftime('%d-%m-%y'),
                streak=1,
                completed=True,
                history=[1],
                streak_history=[0],
                completion_history=[[
                datetime.now().date().strftime('%d-%m-%y'),
                datetime.now().strftime('%H-%M-%S')
                ]]
                )

    habit.refresh()
    completed = habit.get_completed()
    completion_history = habit.get_history()
    streak = habit.get_streak()
    assert completed == True
    assert completion_history[-1] == 1
    assert streak==1
    
def test_change_periodicity():
    habit = Habit(task_specification="test",
                periodicity="daily")
    habit.change_periodicity()
    assert habit.get_periodicity() == "weekly"
    
def test_get_streak():
    habit = Habit(task_specification="test",
                streak=5)
    assert habit.get_streak() == 5

def test_get_longest_streak():
    habit = Habit(task_specification="test",
                streak_history=[3,7,12,7,1,2])
    assert habit.get_longest_streak() == 12
    
def test_set_streak():
    habit = Habit(task_specification="test",
                streak=0)
    for number in range(1,5):
        habit.set_streak()
        assert habit.get_streak() == number
        
def test_reset_streak():
    habit = Habit(task_specification="test",
                streak=5,
                streak_history=[])
    habit.reset_streak()
    assert habit.get_streak() == 0
    assert habit.get_streak_history() == [5]
    
def test_get_task():
    habit = Habit(task_specification="test")
    assert habit.get_task() == "test"
    
def test_get_day_of_creation():
    date = datetime.now().date()
    habit = Habit(task_specification="test",
                date_of_creation=date)
    assert habit.get_day_of_creation() == date
    
def test_get_history():
    habit = Habit(task_specification="test",
                    history=[0,1,0,1,1,0,1,0,0,1,0,1,0,1,1,1,1])
    assert habit.get_history() == [0,1,0,1,1,0,1,0,0,1,0,1,0,1,1,1,1]
    
def test_get_periodicity():
    habit = Habit(task_specification="test",
                periodicity="daily")
    assert habit.get_periodicity() == "daily"

def test_get_completed():
    habit = Habit(task_specification="test",
                completed=True)
    assert habit.get_completed() == True
    
def test_complete():
    time = datetime.now() - timedelta(days=1)
    habit = Habit(task_specification="test",
                completed=False,
                date_of_creation=time.date().strftime('%d-%m-%y'),
                completion_history=[[time.date().strftime('%d-%m-%y'), time.strftime('%H-%M-%S')]],
                streak=5,
                history=[1])
    habit.complete()
    assert habit.get_completed() == True
    assert habit.get_streak() == 6
    assert habit.get_history() == [1,1]
    
def test_load_user_from_json():
    json_string = json.dumps({
                                "_name" : "test",
                                "_age" : 99,
                                "_creation" : "01-01-1900"
                            })
    
    user = User.load_user_from_json(json_string)
    assert user.get_name() == "test"
    assert user.get_age() == 99
    assert user.get_creation() == "01-01-1900"
    
def test_get_name():
    user = User("test name", 99)
    assert user.get_name() == "test name"
    
def test_get_age():
    user = User("test name", 99)
    assert user.get_age() == 99
    
def test_get_creation():
    user = User("test name", 99, creation="01-01-1900")
    assert user.get_creation() == "01-01-1900"
    
def test_recreate_habit():
    user = User("test name",99)
    habit = Habit("test habit")
    user.recreate_habit(habit)
    assert user.get_all_habits()[-1] == habit
    
def test_add_habit():
    user = User("test name", 99)
    user.add_habit("test habit","daily")
    assert user.get_all_habits()[-1].get_task() == "test habit"
    assert user.get_all_habits()[-1].get_periodicity() == "daily"
    
def test_get_habit():
    user = User("test name", 99)
    user.add_habit("test habit", "daily")
    assert user.get_habit("test habit").get_task() == "test habit"
    assert user.get_habit("test habit").get_periodicity() == "daily"

def test_get_weekly_habits():
    user = User("test name", 99)
    user.add_habit("test habit 1 (getweekly)", "daily")
    user.add_habit("test habit 2", "weekly")
    assert user.get_weekly_habits()[-1] == "test habit 2"
    
def test_get_daily_habits():
    user = User("test name", 99)
    user.add_habit("test habit 3", "daily")
    user.add_habit("test habit 4", "weekly")
    assert user.get_daily_habits()[-1] == "test habit 3"

def test_get_all_habits():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test habit 1")
    habit2 = Habit(task_specification="test habit 2")
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    assert user.get_all_habits()[-1] == habit2
    assert user.get_all_habits()[-2] == habit1
    
def test_get_all_tasks():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test habit 1")
    habit2 = Habit(task_specification="test habit 2")
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    assert user.get_all_tasks()[-1] == "test habit 2"
    assert user.get_all_tasks()[-2] == "test habit 1"
    
def test_remove_habit():
    user = User("test user", 98)
    user.add_habit("test habit remove 1", "daily")
    user.add_habit("test habit remove 2", "weekly")
    user.remove_habit("test habit remove 2")
    assert user.get_all_tasks()[-1] == "test habit remove 1"
    
def test_get_current_streaks():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test3",
                streak=3)
    habit2 = Habit(task_specification="test5",
                streak=5
                )
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    assert user.get_current_streaks()[-2] == ["test3", 3]
    assert user.get_current_streaks()[-1] == ["test5", 5]
    
def test_get_longest_streaks():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test3",
                streak_history=[0,5,7,12,2,5])
    habit2 = Habit(task_specification="test5",
                streak_history=[3,9,7,15,4]
                )
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    assert user.get_longest_streaks()[-2] == ["test3", 12]
    assert user.get_longest_streaks()[-1] == ["test5", 15]
    
def test_set_complete():
    user = User("test name", 99)
    habit = Habit(task_specification="test set complete",
                   completed=False)
    user.recreate_habit(habit)
    user.set_complete("test set complete")
    completed, _ = user.get_completed()
    assert completed[-1][0] == "test set complete"
    
def test_get_completed():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test get completed",
                   completed=True)
    
    habit2 = Habit(task_specification="test get incompleted",
                   completed=False)
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    completed, incompleted = user.get_completed()
    assert completed[-1][0] == "test get completed"
    assert incompleted[-1][0] == "test get incompleted"
    
def test_weekly_struggle():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test weekly struggle 1",
                   periodicity="weekly",
                   history=[0,1,1,1,1,0,1,1])
    habit2 = Habit(task_specification="test weekly struggle 2",
                   periodicity="weekly",
                   history=[0,0,0,0,1,1,0,0,1])
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    assert user.weekly_struggle(weeks=4) == [["test weekly struggle 1", 1],["test weekly struggle 2", 2]]
    
def test_daily_struggle():
    user = User("test name", 99)
    habit1 = Habit(task_specification="test daily struggle 1",
                   periodicity="daily",
                   history=[0,1,1,1,1,0,1,1])
    habit2 = Habit(task_specification="test daily struggle 2",
                   periodicity="daily",
                   history=[0,0,0,0,1,1,0,0,1])
    user.recreate_habit(habit1)
    user.recreate_habit(habit2)
    assert user.daily_struggle(days=4) == [["test daily struggle 1", 1],["test daily struggle 2", 2]]
    
def test_get_day_of_creation():
    time = datetime.now().strftime('%d.%m.%y')
    user = User("test name", 99)
    habit = Habit("test habit get day of creation", date_of_creation=time)
    user.recreate_habit(habit)
    assert user.get_day_of_creation("test habit get day of creation") == time

def test_refresh_habits():
    time = datetime.now() - timedelta(days=3)
    user = User("test name", 99)
    habit = Habit(task_specification="test",
            periodicity="daily",
            completed=True,
            date_of_creation=time.date().strftime('%d-%m-%y'),
            completion_history=[[time.date().strftime('%d-%m-%y'), time.strftime('%H-%M-%S')]],
            streak=5,
            history=[1])
    user.recreate_habit(habit)
    user.refresh_habits()
    assert habit.get_completed() == False
    assert habit.get_streak() == 0
    assert habit.get_history() == [1,0,0]