import os

from pytest import ExitCode


with open(os.path.join(os.path.split(__file__)[0], "requirements.txt"), "r") as req:
        for line in req:
            package = line.split("\n")[0]
            try:
                os.system('pip install ' + package)
            except ExitCode(1):
                print("You've already installed the requirement: " + package)