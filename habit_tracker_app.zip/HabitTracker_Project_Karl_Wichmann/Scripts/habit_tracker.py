import json

from datetime import datetime, timedelta



class Habit:
    """
    A class to represent a habit object
    
    ...
    
    Attributes
    ----------
    task_specification : str
        name of the habit
    periodicity : str
        periodicity of the habit
    date_of_creation : str
        the date of creation of this class
    streak : int
        number of completions without breaking the habits periodicity
    streak_history : list
        stores streaks when they get broken
    completed : bool
        stores whether the habit is completed or not
    history : list
        stores 0 or 1 dependend on if the habit was completed or not
    completion_history : list
        stores the time if the habit has been completed
    
    Methods
    --------
    load_habit_from_json(class_as_json:str)
        Loads a habit from a json string
    refresh()
        "Breaks" the streak, if last completion is to far away
    change_periodicity()
        Changes the periodicity
    get_streak()
        Returns the streak
    get_streak_history()
        Returns the streak_history
    get_longest_streak()
        Returns the longest streak the habit ever had
    set_streak():
        Sets the habits streak plus one
    reset_streak()
        Appends streak_history with the current streak and sets streak to zero
    get_task()
        Returns the task_specification
    get_day_of_creation()
        Returns the creation
    get_history()
        Returns the history
    get_periodicity()
        Returns the periodicity
    get_completed()
        Returns if the habit is completed
    complete()
        Sets the habit to complete,
        sets the streak plus one
        appends the history plus one
        and appends completion_history
        
    """
    def __init__(
                self,
                task_specification:str,
                periodicity:str="daily",
                date_of_creation:str=datetime.now().strftime('%d-%m-%y'),
                streak:int=1,
                completed:bool=True,
                history:list=[1],
                streak_history:list=[],
                completion_history:list=[[datetime.now().date().strftime('%d-%m-%y'), datetime.now().strftime('%H-%M-%S')]],
                 ):
        """
        Parameters
        ----------
        task_specification : str
            name of the habit
        periodicity : str
            periodicity of the habit
        date_of_creation : str
            the date of creation of this class (default is at the time of method call)
        streak : int
            number of completions without breaking the habits periodicity (defaul is 1)
        streak_history : list
            stores streaks when they get broken (default is [1])
        completed : bool
            stores whether the habit is completed or not (deafult is True)
        history : list
            stores 0 or 1 dependend on if the habit was completed or not (default is [1])
        completion_history : list
            stores the time if the habit has been completed (default is [date of method call, time of method call])
        """
        self.task_specification:str = task_specification.lower()
        self.periodicity = periodicity.lower()
        self.date_of_creation = date_of_creation
        self.streak = streak
        self.completed = completed
        self.history = history
        self.streak_history = streak_history
        self.completion_history = completion_history
        
        
    @classmethod
    def load_habit_from_json(cls, class_as_json:str):
        """Loads a habit object from a json string
        
        Parameters
        ----------
        class_as_json : str
            A habit object's json string
        """
        
        habit = json.loads(class_as_json)
        return cls(task_specification=habit["task_specification"],
                   periodicity=habit["periodicity"],
                   date_of_creation=habit["date_of_creation"],
                   streak=habit["streak"],
                   completed=habit["completed"],
                   history=habit["history"],
                   streak_history=habit["streak_history"],
                   completion_history=habit["completion_history"]
                   )
     
    # Refresh the Habit, every day or each time the user starts the program
    def refresh(self):
        """
        "Breaks" the streak, if last completion is to far behind
        """
        
        time = datetime.now().date()
        # If time now is bigger than
        if time > datetime.strptime(self.completion_history[-1][0], '%d-%m-%y').date():
            # Check if Habit is daily
            if self.periodicity == "daily":
                self.completed = False
                # If time now is 2 days or later than the last completion
                if (time - timedelta(days=1)) > datetime.strptime(self.completion_history[-1][0],'%d-%m-%y').date():
                    # Break the Streak
                    absent_days = (time - datetime.strptime(self.completion_history[-1][0],'%d-%m-%y').date()).days
                    # Append the history with the number of zeros equal to the number of absent days
                    for i in range(int(absent_days)-1):
                        self.history.append(0)
                    self.reset_streak()
                    return True
            else:
                # If time now is 8 days or later than the last completion
                if (time - timedelta(days=7)) > datetime.strptime(self.completion_history[-1][0],'%d-%m-%y').date():
                    absent_weeks = (time - datetime.strptime(self.completion_history[-1][0],'%d-%m-%y')).days // 7
                    # Append the history with the number of zeros equal to the number of absent weeks
                    for i in range(absent_weeks):
                        self.history.append(0)
                    self.reset_streak()
                    return True
        return False
    
    def change_periodicity(self):
        """
        Changes the periodicity
        """
        
        if self.periodicity == "daily":
            self.periodicity = "weekly"
        else:
            self.periodicity = "daily"

    def get_streak(self):
        """
        Returns the streak
        """
        
        return self.streak
    
    def get_streak_history(self):
        """
        Returns the streak_history
        """
        
        return self.streak_history
    
    def get_longest_streak(self):
        """
        Returns the longest streak the habit ever had
        """
        
        if self.streak_history:
            _longest_streak = max(self.streak, max(self.streak_history))
            return _longest_streak
        return self.streak
    
    def set_streak(self):
        """
        Sets the habits streak plus one
        """
        
        self.streak += 1
        self.completed = False
             
    def reset_streak(self):
        """
        Appends streak_history with the current streak and sets streak to zero
        """
        
        self.streak_history.append(self.streak)
        self.streak = 0
             
    def get_task(self):
        """
        Returns the task_specification
        """
        
        return self.task_specification
     
    def get_day_of_creation(self):
        """
        Returns the creation
        """
        
        return self.date_of_creation
      
    def get_history(self):
        """
        Returns the history
        """
        
        return self.history
    
    def get_periodicity(self):
        """
        Returns the periodicity
        """
        
        return self.periodicity
     
    def get_completed(self):
        """
        Returns if the habit is completed
        """
        
        return self.completed
    
    def get_completion_history(self):
        """
        Returns the completion_history
        """
        
        return self.completion_history
    
    def complete(self):
        """
        Sets the habit to complete,
        sets the streak plus one,
        appends the history plus one,
        and appends completion_history
        """
        # If date now is one day or more later
        if datetime.strptime(self.completion_history[-1][0], "%d-%m-%y").date() < datetime.now().date():
            self.set_streak()
            self.history.append(1)
            time = datetime.now().strftime('%H-%M-%S')
            date = datetime.now().date().strftime('%d-%m-%y')
            self.completion_history.append([date, time])
        self.completed = True
        return True
        
        
class User:
    """
    A class to represent a user object
    
    ...
    
    Attributes
    ----------
    name : str
        The name of the user
    age : str
        The age og the user
    habits : list
        A list containing the habits assigned to the user
    creation : str
        A string representing the date and time
        
    Methods
    -------
    load_user_from_json(class_as_json)
        Loads a User object from a json string
    get_name()
        Returns the name
    get_age()
        Returns the age
    get_creation()
        Returns the creation date and time
    recreate_habit(habit:Habit)
        Appends the habits list with a habit object
    add_habit(task_specification:str, periodicity:str)
        Creates a habit object and appends the habits list with the new habit obejct
    get_habit(task_specifiaction:str)
        Returns a habit object with the given name
    get_weekly_habits()
        Returns the habit specification of the weekly habits
    get_daily_habits()
        Returns the habit specification of the daily habits
    get_all_habits()
        Returns all habit objects
    get_all_tasks()
        Returns the habit specification of all habits
    remove_habit(habit_specification)
        Removes a habit from the habit list
    get_current_streaks()
        Returns a list containing the current streaks of all habits
    get_longest_streaks()
        Return a list containing the longest streaks of all habits
    set_complete(habit_specifiaction)
        Sets a habit complete
    get_completed()
        Returns a list containing all completed and incompleted habits
    weekly_struggle()
        Returns a list of lists ([[habit_specification, number_of_zeros]]) sorted by the number of zeros (incompletion)
        in the history list of all weekly habits
    daily_struggle()
        Returns a list of lists ([[habit_specification, number_of_zeros]]) sorted by the number of zeros (incompletion)
        in the history list of all daily habits
    get_day_of_creation(habit_specification)
        Returns the day of creation of a habit
    refresh_habits()
        Calls the refresh method of each habit in the habit list
    """
    
    def __init__(self, name:str,
                age:int,
                habits:list=[],
                creation:str=datetime.now().strftime('%d.%m.%y-%H:%M:%S')):
        self.name = name
        self.age = age
        self.habits = habits
        self.creation = creation
        
    @classmethod
    def load_user_from_json(cls, class_as_json):
        """
        Loads a User object from a json string
        
        Parameters
        ----------
        class_as_json : str
            A habit objects's json string
        """
        user = json.loads(class_as_json)
        return cls(
            name=user["name"],
            age=user["age"],
            habits=[],
            creation=user["creation"]
                   )
        
    def get_name(self):
        """
        Returns the name
        """
        return self.name
    
    def get_age(self):
        """
        Returns the age
        """
        return self.age
    
    def get_creation(self):
        """
        Returns the creation date and time
        """
        return self.creation
        
    def recreate_habit(self, habit:Habit):
        """
        Appends the habits list with a habit object
        
        Parameters
        ----------
        habit : Habit
            A habit object
        """
        self.habits.append(habit)
        
    def add_habit(self, habit_specification:str, periodicity:str):
        """
        Creates a habit object and appends the habits list with the new habit obejct
        
        Parameters
        ----------
        habit_specification : str
            The name of the habit
        """
        habit = Habit(habit_specification, periodicity)
        self.habits.append(habit)
        
    def get_habit(self, habit_specification:str):
        """
        Returns a habit object with the given name
        
        Parameters
        ----------
        habit_specification : str
            The name of the habit
        """
        for habit in self.habits:
            if habit.get_task().lower() == habit_specification:
                return habit
        return False

    def get_weekly_habits(self):
        """
        Returns the habit specification of the weekly habits
        """
        habits_names = []
        for habit in self.habits:
            if habit.get_periodicity() == "weekly":
                habits_names.append(habit.get_task())
        return habits_names
         
    def get_daily_habits(self):
        """
        Returns the habit specification of the daily habits
        """
        habits_names = []
        for habit in self.habits:
            if habit.get_periodicity() == "daily":
                habits_names.append(habit.get_task())
        return habits_names
    
    def get_all_habits(self):
        """
        Returns all habit objects
        """
        if self.habits:
            return self.habits
        return False
    
    def get_all_tasks(self):
        """
        Returns the habit specification of all habits
        """
        habits_names = []
        for habit in self.habits:
            habits_names.append(habit.get_task())
        return habits_names

    def remove_habit(self, habit_specification:str):
        """
        Removes a habit from the habit list
        
        Parameters
        ----------
        habit_specification : str
            The name of the habit
        """
        habit = self.get_habit(habit_specification)
        if habit in self.habits:
            self.habits.remove(habit)
            return True
        return False
        
    def get_current_streaks(self):
        """
        Returns a list containing the current streaks of all habits
        """
        streaks = []
        for habit in self.habits:
            streaks.append([habit.get_task(), habit.get_streak()])
        return sorted(streaks, key=lambda t: t[1])
    
    def get_longest_streaks(self):
        """
        Return a list containing the longest streaks of all habits
        """
        streaks = []
        for habit in self.habits:
           streaks.append([habit.get_task(), habit.get_longest_streak()])
        return sorted(streaks, key=lambda t: t[1])
    
    def set_complete(self, habit_specification:str):
        """
        Sets a habit complete
        
        Parameters
        ----------
        habit_specification : str
            The name of the habit
        """
        for habit in self.habits:
            if habit.get_task() == habit_specification:
                habit.complete()
                return True
        return False
    
    def get_completed(self):
        """
        Returns two lists containing all completed and incompleted habits
        """ 
        completed = []
        incompleted = []
        for habit in self.habits:
            if habit.get_completed() == True:
                completed.append([habit.get_task(), habit.get_completion_history()[-1][0]])
            else:
                incompleted.append([habit.get_task(), habit.get_completion_history()[-1][0]])
        return completed, incompleted    
    
    def weekly_struggle(self, weeks:int=2):
        """
        Returns a list of lists ([[habit_specification, number_of_zeros]]) sorted by the number of zeros (incompletion)
        in the history list of all weekly habits
        
        Parameters
        ----------
        weeks : int
            The number of weeks the function looks for the incompletion of habits
            
        """
        histories = []
        for habit in self.habits:
            # If the number of values in habit's history is equal or greater than the weeks given
            if len(habit.get_history()) >= weeks and habit.get_periodicity() == "weekly":
                histories.append([habit.get_task(), habit.get_history()[-weeks:].count(0)])
        # If list of struggles is not empty
        if len(histories) > 0:
            sorted_histories = sorted(histories, key=lambda t: t[1])
            return sorted_histories
        return ["You had no habits active for that long"]
    
    def daily_struggle(self, days:int=5):
        """
        Returns a list of lists ([[habit_specification, number_of_zeros]]) sorted by the number of zeros (incompletion)
        in the history list of all daily habits
        
        Parameters
        ----------
        days : int
            The number of days the function looks for the incompletion of habits
        """
        histories = []
        for habit in self.habits:
            # If the number of values in habit's history is equal or greater than the days given
            if len(habit.get_history()) >= days and habit.get_periodicity() == "daily":
                histories.append([habit.get_task(), habit.get_history()[-days:].count(0)])
        # If list of struggles is not empty
        if len(histories) > 0:
            sorted_histories = sorted(histories, key=lambda t: t[1])
            return sorted_histories
        return ["You had no habits active for that long"]
    
    def get_day_of_creation(self, habit_specification:str):
        """
        Returns the day of creation of a habit
        
        Parameters
        ----------
        habit_specification : str
        The name of the habit
        """
        return self.get_habit(habit_specification).get_day_of_creation()
         
    def refresh_habits(self):
        """
        Calls the refresh method of each habit in the habit list
        """
        for habit in self.habits:
            habit.refresh()